// Readme for SWEN30006 Software Modelling and Design
// Project 2
//
// Author     : Adrian Sutanahadi
// Login ID   : asutanahadi
// Student ID : 617462
//

Please run these commands in order to run the rails app:

bundle install
rake db:create
rake db:migrate
rake db:seed
rails r lib/scraperbom.rb
rails r lib/scraperjson.rb
whenever --update-crontab
rails s
