class Source < ActiveRecord::Base
	has_many :readings
end
